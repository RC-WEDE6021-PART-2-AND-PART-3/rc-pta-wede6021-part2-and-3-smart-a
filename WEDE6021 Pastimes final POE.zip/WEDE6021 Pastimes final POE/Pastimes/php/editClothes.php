<?php
include("DBConn.php");

$id = $_GET['id'];

$result = $conn->query("SELECT * FROM tblClothes WHERE itemID=$id");
$item = $result->fetch_assoc();

if(isset($_POST['update']))
{
    $itemName = $_POST['itemName'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    $conn->query("
    UPDATE tblClothes
    SET itemName='$itemName',
        brand='$brand',
        price='$price',
        image='$image'
    WHERE itemID=$id
    ");

    header("Location: admin.php");
    exit();
}
?>

<h2>Edit Clothing Item</h2>

<form method="POST">

Item Name:
<br>
<input type="text"
name="itemName"
value="<?php echo $item['itemName']; ?>">
<br><br>

Brand:
<br>
<input type="text"
name="brand"
value="<?php echo $item['brand']; ?>">
<br><br>

Price:
<br>
<input type="text"
name="price"
value="<?php echo $item['price']; ?>">
<br><br>

Image:
<br>
<input type="text"
name="image"
value="<?php echo $item['image']; ?>">
<br><br>

<button type="submit" name="update">
Update Item
</button>

</form>