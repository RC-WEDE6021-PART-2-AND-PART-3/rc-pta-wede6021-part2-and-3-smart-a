<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include("DBConn.php");

if (isset($_GET['approve'])) {
    $id = $_GET['approve'];

    $conn->query("
    UPDATE tblSellRequest
    SET status='Approved'
    WHERE requestID=$id
    ");
}

if (isset($_GET['reject'])) {
    $id = $_GET['reject'];

    $conn->query("
    UPDATE tblSellRequest
    SET status='Rejected'
    WHERE requestID=$id
    ");
}

$result = $conn->query("SELECT * FROM tblSellRequest");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Requests</title>
</head>
<body>

<h2>Seller Requests</h2>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>User ID</th>
    <th>Item Name</th>
    <th>Brand</th>
    <th>Description</th>
    <th>Image</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>
    <td><?php echo $row['requestID']; ?></td>
    <td><?php echo $row['userID']; ?></td>
    <td><?php echo $row['itemName']; ?></td>
    <td><?php echo $row['brand']; ?></td>
    <td><?php echo $row['description']; ?></td>
    <td><?php echo $row['image']; ?></td>
    <td><?php echo $row['status']; ?></td>

    <td>
        <a href="?approve=<?php echo $row['requestID']; ?>">Approve</a> |
        <a href="?reject=<?php echo $row['requestID']; ?>">Reject</a>
    </td>
</tr>

<?php } ?>

</table>

</body>
</html>