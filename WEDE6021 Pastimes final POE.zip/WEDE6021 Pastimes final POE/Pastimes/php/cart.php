<?php
session_start();
include("DBConn.php");

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_GET['add'])) {

    $itemID = $_GET['add'];

    if (isset($_SESSION['cart'][$itemID])) {
        $_SESSION['cart'][$itemID]++;
    } else {
        $_SESSION['cart'][$itemID] = 1;
    }
}

echo "<h2>Shopping Cart</h2>";

$total = 0;

echo "<table border='1' cellpadding='10'>";
echo "<tr>
        <th>Item</th>
        <th>Price</th>
        <th>Quantity</th>
      </tr>";

foreach ($_SESSION['cart'] as $itemID => $qty) {

    $result = $conn->query(
        "SELECT * FROM tblclothes WHERE itemID=$itemID"
    );

    $row = $result->fetch_assoc();

    $subtotal = $row['price'] * $qty;
    $total += $subtotal;

    echo "<tr>
            <td>".$row['itemName']."</td>
            <td>R".$row['price']."</td>
            <td>".$qty."</td>
          </tr>";
}

echo "</table>";

echo "<h3>Total: R".$total."</h3>";

echo "<a href='products.php'>Continue Shopping</a>";
echo "<br><br>";
echo "<a href='checkout.php'>Checkout</a>";
?>