<?php
include("DBConn.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullName = $_POST['fullName'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    // Check password length
    if (strlen($password) < 8) {
        $message = "Password must be at least 8 characters.";

    // Check passwords match
    } elseif ($password !== $confirm) {
        $message = "Passwords do not match.";

    } else {
        // Check if username already exists
        $check = $conn->query("SELECT * FROM tblUser WHERE username='$username'");

        if ($check->num_rows > 0) {
            $message = "Username already taken. Please choose another.";

        } else {
            $hashed = md5($password);
            $sql = "INSERT INTO tblUser (fullName, email, username, password, seller_status)
                    VALUES ('$fullName', '$email', '$username', '$hashed', 'pending')";

            if ($conn->query($sql) === TRUE) {
                $message = "Registered successfully! Waiting for admin approval.";
            } else {
                $message = "Error: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pastimes - Register</title>
</head>
<body>

<h2>Register</h2>

<form method="POST">
    Full Name: <input type="text" name="fullName" 
               value="<?= isset($_POST['fullName']) ? $_POST['fullName'] : '' ?>" required><br><br>
    Email: <input type="email" name="email" 
           value="<?= isset($_POST['email']) ? $_POST['email'] : '' ?>" required><br><br>
    Username: <input type="text" name="username" 
              value="<?= isset($_POST['username']) ? $_POST['username'] : '' ?>" required><br><br>
    Password: <input type="password" name="password" minlength="8" required><br><br>
    Confirm Password: <input type="password" name="confirm" required><br><br>
    <button type="submit">Register</button>
</form>

<p><?php echo $message; ?></p>
<a href="login.php">Already registered? Login here</a>

</body>
</html>
