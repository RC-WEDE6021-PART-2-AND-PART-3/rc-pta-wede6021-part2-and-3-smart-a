<?php
session_start();
include("DBConn.php");

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    die("Your cart is empty.");
}

$userID = $_SESSION['userID']; // Assuming userID is stored during login

$totalAmount = 0;

foreach ($_SESSION['cart'] as $itemID => $qty) {

    $result = $conn->query("SELECT * FROM tblclothes WHERE itemID = $itemID");
    $row = $result->fetch_assoc();

    $totalAmount += ($row['price'] * $qty);
}

$conn->query("
INSERT INTO tblorders(userID,totalAmount)
VALUES('$userID','$totalAmount')
");

$orderID = $conn->insert_id;

foreach ($_SESSION['cart'] as $itemID => $qty) {

    $result = $conn->query("SELECT * FROM tblclothes WHERE itemID = $itemID");
    $row = $result->fetch_assoc();

    $price = $row['price'];

    $conn->query("
    INSERT INTO tblorderline(orderID,itemID,quantity,price)
    VALUES('$orderID','$itemID','$qty','$price')
    ");
}

$orderNumber = "ORD".$orderID;
$sessionID = session_id();

$_SESSION['cart'] = [];

echo "<h2>Checkout Successful</h2>";
echo "<p>Order Number: ".$orderNumber."</p>";
echo "<p>Session ID: ".$sessionID."</p>";
echo "<p>Total Amount: R".$totalAmount."</p>";

echo "<a href='products.php'>Continue Shopping</a>";
?>