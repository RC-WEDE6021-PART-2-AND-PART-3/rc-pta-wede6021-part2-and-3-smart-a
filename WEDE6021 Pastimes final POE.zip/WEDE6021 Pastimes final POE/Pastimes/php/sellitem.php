<?php
session_start();
include("DBConn.php");

if(isset($_POST['submit']))
{
    $userID = $_SESSION['userID'];
    $itemName = $_POST['itemName'];
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $image = $_POST['image'];

    $sql = "INSERT INTO tblSellRequest
    (userID,itemName,brand,description,image)
    VALUES
    ('$userID','$itemName','$brand','$description','$image')";

    if($conn->query($sql))
{
    echo "<script>
            alert('Request Submitted Successfully');
            window.location='dashboard.php';
          </script>";
}
}
?>

<h2>Sell Clothing Item</h2>

<form method="POST">

Item Name:<br>
<input type="text" name="itemName" required>
<br><br>

Brand:<br>
<input type="text" name="brand" required>
<br><br>

Description:<br>
<textarea name="description" required></textarea>
<br><br>

Image Filename:<br>
<input type="text" name="image" required>
<br><br>

<button type="submit" name="submit">
Submit Request
</button>

</form>