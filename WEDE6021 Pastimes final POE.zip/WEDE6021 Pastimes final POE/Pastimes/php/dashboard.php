<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pastimes Dashboard</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
        }

        body{
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height:100vh;
        }

        .container{
            width:90%;
            max-width:1000px;
            margin:auto;
            padding-top:50px;
        }

        .header{
            background:white;
            padding:30px;
            border-radius:15px;
            text-align:center;
            box-shadow:0 5px 15px rgba(0,0,0,0.2);
            margin-bottom:30px;
        }

        .header h1{
            color:#1e3c72;
        }

        .header p{
            color:gray;
            margin-top:10px;
        }

        .menu{
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
            gap:20px;
        }

        .card{
            background:white;
            padding:30px;
            border-radius:15px;
            text-align:center;
            box-shadow:0 5px 15px rgba(0,0,0,0.2);
            transition:0.3s;
        }

        .card:hover{
            transform:translateY(-5px);
        }

        .card h3{
            color:#1e3c72;
            margin-bottom:10px;
        }

        .card p{
            margin-bottom:20px;
            color:#555;
        }

        .card a{
            text-decoration:none;
            background:#007BFF;
            color:white;
            padding:10px 20px;
            border-radius:5px;
            display:inline-block;
        }

        .card a:hover{
            background:#0056b3;
        }

    </style>
</head>

<body>

<div class="container">

    <div class="header">
        <h1>Pastimes Clothing Store</h1>
        <p>Welcome, <?php echo $_SESSION['fullName']; ?></p>
    </div>

    <div class="menu">

        <div class="card">
            <h3>Products</h3>
            <p>Browse available clothing items.</p>
            <a href="products.php">View Products</a>
        </div>

        <div class="card">
            <h3>Sell Clothing</h3>
            <p>Submit a request to sell your clothing.</p>
            <a href="sellItem.php">Sell Item</a>
        </div>

        <div class="card">
            <h3>Purchase History</h3>
            <p>View all previous purchases.</p>
            <a href="purchaseHistory.php">View History</a>
        </div>

        <div class="card">
            <h3>Admin Panel</h3>
            <p>Manage users, clothes and requests.</p>
            <a href="admin.php">Open Admin</a>
        </div>

        <div class="card">
            <h3>Logout</h3>
            <p>Securely sign out of the system.</p>
            <a href="logout.php">Logout</a>
        </div>

    </div>

</div>

</body>
</html>