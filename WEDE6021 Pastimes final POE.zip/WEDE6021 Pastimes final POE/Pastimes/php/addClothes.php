<?php
include("DBConn.php");

if(isset($_POST['submit']))
{
    $itemName = $_POST['itemName'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    $sql = "INSERT INTO tblClothes
    (itemName, brand, price, image)
    VALUES
    ('$itemName', '$brand', '$price', '$image')";

    if($conn->query($sql))
{
    echo "<script>
            alert('Item Added Successfully');
            window.location='admin.php';
          </script>";
    exit();
}
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Clothes</title>
</head>
<body>

<h2>Add Clothing Item</h2>

<form method="POST">

Item Name:
<br>
<input type="text" name="itemName" required>
<br><br>

Brand:
<br>
<input type="text" name="brand" required>
<br><br>

Price:
<br>
<input type="number" step="0.01" name="price" required>
<br><br>

Image Filename:
<br>
<input type="text" name="image" required>
<br><br>

<button type="submit" name="submit">
Add Item
</button>

</form>

</body>
</html>