<?php
session_start();
include("DBConn.php");

$userID = $_SESSION['userID'];

$sql = "SELECT *
        FROM tblorders
        WHERE userID='$userID'
        ORDER BY orderDate DESC";

$result = $conn->query($sql);

$totalSpent = 0;

echo "<h2>Purchase History</h2>";

echo "<table border='1' cellpadding='10'>";
echo "<tr>
        <th>Order ID</th>
        <th>Date</th>
        <th>Total Amount</th>
      </tr>";

while($row = $result->fetch_assoc())
{
    echo "<tr>";
    echo "<td>".$row['orderID']."</td>";
    echo "<td>".$row['orderDate']."</td>";
    echo "<td>R".$row['totalAmount']."</td>";
    echo "</tr>";

    $totalSpent += $row['totalAmount'];
}

echo "</table>";

echo "<h3>Total Purchases: R".$totalSpent."</h3>";
?>