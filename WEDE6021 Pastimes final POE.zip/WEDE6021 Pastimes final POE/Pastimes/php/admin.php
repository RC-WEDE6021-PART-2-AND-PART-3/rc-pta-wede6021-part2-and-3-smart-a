<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include("DBConn.php");

/* APPROVE USER */
if (isset($_GET['approve'])) {
    $id = $_GET['approve'];
    $conn->query("UPDATE tblUser SET status='approved' WHERE userID=$id");
}

/* DELETE USER */
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM tblUser WHERE userID=$id");
}

/* DELETE CLOTHING ITEM */
if (isset($_GET['deleteItem'])) {
    $id = $_GET['deleteItem'];
    $conn->query("DELETE FROM tblClothes WHERE itemID=$id");
}

/* FETCH USERS */
$result = $conn->query("SELECT * FROM tblUser");

/* FETCH CLOTHES */
$items = $conn->query("SELECT * FROM tblClothes");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <style>
body{
    font-family:Arial, sans-serif;
    background:#f4f6f8;
    padding:20px;
}

h2,h3{
    color:#1e3c72;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

th{
    background:#007BFF;
    color:white;
    padding:12px;
}

td{
    padding:10px;
    text-align:center;
}

tr:nth-child(even){
    background:#f2f2f2;
}

a{
    text-decoration:none;
    font-weight:bold;
}
</style>
</head>
<body>

<h2>Admin Panel</h2>
<a href="manageRequests.php">Manage Seller Requests</a>
<br><br>

<h3>Manage Users</h3>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Username</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>
    <td><?php echo $row['userID']; ?></td>
    <td><?php echo $row['fullName']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['status']; ?></td>

    <td>
        <a href="?approve=<?php echo $row['userID']; ?>">Approve</a> |
        <a href="?delete=<?php echo $row['userID']; ?>">Delete</a>
    </td>
</tr>

<?php } ?>

</table>

<br><br>

<h3>Manage Clothes</h3>

<a href="addClothes.php">Add New Clothing Item</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Item Name</th>
    <th>Brand</th>
    <th>Price</th>
    <th>Action</th>
</tr>

<?php while($item = $items->fetch_assoc()) { ?>

<tr>
    <td><?php echo $item['itemID']; ?></td>
    <td><?php echo $item['itemName']; ?></td>
    <td><?php echo $item['brand']; ?></td>
    <td>R<?php echo $item['price']; ?></td>

    <td>
        <a href="editClothes.php?id=<?php echo $item['itemID']; ?>">Edit</a> |
        <a href="?deleteItem=<?php echo $item['itemID']; ?>">Delete</a>
    </td>
</tr>

<?php } ?>

</table>

</body>
</html>