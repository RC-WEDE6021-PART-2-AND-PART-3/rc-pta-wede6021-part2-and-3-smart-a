-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2026 at 11:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pastimesdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcart`
--

CREATE TABLE `tblcart` (
  `cartID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `itemID` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblclothes`
--

CREATE TABLE `tblclothes` (
  `itemID` int(11) NOT NULL,
  `itemName` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblclothes`
--

INSERT INTO `tblclothes` (`itemID`, `itemName`, `brand`, `price`, `image`) VALUES
(2, 'Addidas T-shirt', 'Addidas', 599.99, 'tshirt.jpeg'),
(4, 'Nike Hoodie', 'Nike', 590.99, 'nikehoodie.jpg'),
(6, 'Nike Hoodie', 'Nike', 599.99, 'nikehoodie.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblorderline`
--

CREATE TABLE `tblorderline` (
  `orderLineID` int(11) NOT NULL,
  `orderID` int(11) DEFAULT NULL,
  `itemID` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblorderline`
--

INSERT INTO `tblorderline` (`orderLineID`, `orderID`, `itemID`, `quantity`, `price`) VALUES
(1, 1, 1, 2, 899.99),
(2, 1, 2, 3, 499.99),
(3, 2, 2, 2, 499.99),
(4, 3, 2, 2, 499.99),
(5, 3, 1, 1, 899.99),
(6, 4, 2, 1, 599.99),
(7, 4, 3, 1, 599.99),
(8, 5, 2, 1, 599.99),
(9, 5, 3, 1, 599.99),
(10, 6, 2, 1, 599.99),
(11, 6, 4, 1, 599.99),
(12, 7, 2, 1, 599.99),
(13, 7, 3, 1, 599.99);

-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--

CREATE TABLE `tblorders` (
  `orderID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `orderDate` datetime DEFAULT current_timestamp(),
  `totalAmount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblorders`
--

INSERT INTO `tblorders` (`orderID`, `userID`, `orderDate`, `totalAmount`) VALUES
(1, 0, '2026-06-15 15:51:07', 3299.95),
(2, 3, '2026-06-15 15:52:40', 999.98),
(3, 3, '2026-06-15 16:03:15', 1899.97),
(4, 3, '2026-06-15 17:46:22', 1199.98),
(5, 3, '2026-06-16 11:22:31', 1199.98),
(6, 3, '2026-06-16 11:29:20', 1199.98),
(7, 3, '2026-06-16 11:32:33', 1199.98);

-- --------------------------------------------------------

--
-- Table structure for table `tblsellrequest`
--

CREATE TABLE `tblsellrequest` (
  `requestID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `itemName` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsellrequest`
--

INSERT INTO `tblsellrequest` (`requestID`, `userID`, `itemName`, `brand`, `description`, `image`, `status`) VALUES
(1, 3, 'Nike Hoodie', 'Nike', 'it should be blue and printed nike in bold ', 'nikehoodie.jpg', 'Rejected'),
(2, 3, 'Nike Hoodie', 'Nike', 'it should be pink', 'nikehoodie.jpg', 'Approved'),
(3, 3, 'Nike Hoodie', 'Nike', 'must be warm', 'nikehoodie.jpg', 'Rejected'),
(4, 3, 'Nike Hoodie', 'Nike', 'it should be pink', 'nikehoodie.jpg', 'Rejected'),
(5, 3, 'Nike Hoodie', 'Nike', 'should be yellow', 'nikehoodie.jpg', 'Rejected'),
(6, 3, 'Nike Hoodie', 'Nike', 'should be blue', 'nikehoodie.jpg', 'Approved'),
(7, 3, 'Nike Hoodie', 'Nike', 'yellow', 'nikehoodie.jpg', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `userID` int(11) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `role` varchar(20) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`userID`, `fullName`, `email`, `username`, `password`, `status`, `role`) VALUES
(1, 'Admin User', 'admin@gmail.com', 'admin', '202cb962ac59075b964b07152d234b70', 'approved', 'admin'),
(3, 'Test User', 'test@gmail.com', 'test', '202cb962ac59075b964b07152d234b70', 'approved', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcart`
--
ALTER TABLE `tblcart`
  ADD PRIMARY KEY (`cartID`);

--
-- Indexes for table `tblclothes`
--
ALTER TABLE `tblclothes`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `tblorderline`
--
ALTER TABLE `tblorderline`
  ADD PRIMARY KEY (`orderLineID`);

--
-- Indexes for table `tblorders`
--
ALTER TABLE `tblorders`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `tblsellrequest`
--
ALTER TABLE `tblsellrequest`
  ADD PRIMARY KEY (`requestID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcart`
--
ALTER TABLE `tblcart`
  MODIFY `cartID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblclothes`
--
ALTER TABLE `tblclothes`
  MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblorderline`
--
ALTER TABLE `tblorderline`
  MODIFY `orderLineID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblorders`
--
ALTER TABLE `tblorders`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblsellrequest`
--
ALTER TABLE `tblsellrequest`
  MODIFY `requestID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
